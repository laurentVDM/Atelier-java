package domaine;

public enum Genre {
    HOMME, FEMME, NON_BINAIRE;
}
