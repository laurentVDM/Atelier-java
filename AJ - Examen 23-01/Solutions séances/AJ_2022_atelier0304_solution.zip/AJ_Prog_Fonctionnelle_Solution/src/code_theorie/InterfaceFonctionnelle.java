package code_theorie;

public class InterfaceFonctionnelle {
}
