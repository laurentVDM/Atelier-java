package domaine;

public interface Enfant {

  /**
   * renvoie le nom de l'enfant
   */
  String getNom();

  /**
   * renvoie le téléphone de l'enfant
   */
  String getTelephone();
}
