package utils;

public interface TimeProvider {
  int getCurrentHour();
}
