package domain;

public interface CompactDisc {

  String getTitle();

  String getArtist();
}
