package domaine;

public interface QueryFactory {

	Query getQuery();

}