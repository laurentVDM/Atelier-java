package exceptions;

public class QuantiteNonAutoriseeException extends Exception {

    private static final long serialVersionUID = 1L;

    public QuantiteNonAutoriseeException() {
    }

    public QuantiteNonAutoriseeException(String message) {
        super(message);
    }

}
