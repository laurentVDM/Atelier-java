package marathon;

import java.time.Duration;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface Marathon extends Iterable<Coureur> {
	
	LocalDate getJour();

	void setJour(LocalDate jour);

	String getNom();

	void setNom(String nom);

	/*
	 * La méthode permet l'inscription d'un coureur jusqu'au jour précédent la
	 * course. Elle renvoie false si l'inscription n'a pas pu etre effectuée pour
	 * cette raison ou si le coureur est déjà inscrit.
	 */
	boolean inscrire(Coureur coureur);

	boolean ajouterCheck(String dossard, CheckPoint checkPoint, Duration duration);

	List<Coureur> lesCoureursClasses(CheckPoint checkPoint);
	
	public static enum CheckPoint implements Comparable<CheckPoint> {
		CHECK0(0), CHECK1(10), CHECK2(20), CHECK3(30), CHECK4(40), CHECK5(42.195);
		private double km;

		private CheckPoint(double km) {
			this.km = km;
		}

		public double getKm() {
			return km;

		}
	}

}