package marathon;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

class MarathonImpl implements Marathon {

	private SortedSet<Coureur> coureurs = new TreeSet<Coureur>();
	private LocalDate jour;
	private String nom;
	
	public MarathonImpl() {
		
	}

	public MarathonImpl(String nom, LocalDate localDate) {
		this.jour = localDate;
		this.nom = nom;
	}

	public LocalDate getJour() {
		return jour;
	}

	public void setJour(LocalDate jour) {
		this.jour = jour;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	/*
	 * La méthode permet l'inscription d'un coureur jusqu'au jour précédent la
	 * course. Elle renvoie false si l'inscription n'a pas pu etre effectuée pour
	 * cette raison ou si le coureur est déjà inscrit.
	 */
	@Override
	public boolean inscrire(Coureur coureur) {
		if (this.coureurs.contains(coureur))
			return false;
		if (!LocalDate.now().isBefore(this.jour))
			return false;
		return this.coureurs.add(coureur.clone());
	}

	@Override
	public boolean ajouterCheck(String dossard, CheckPoint checkPoint, Duration duration) {
		Coureur coureur = this.coureurs.stream().filter(x -> x.getDossard().equals(dossard)).findFirst().orElse(null);
		if (coureur == null || !this.coureurs.contains(coureur))
			return false;
		return coureur.ajouterCheck(checkPoint, duration);
	}

	@Override
	public List<Coureur> lesCoureursClasses(CheckPoint checkPoint) {
		return coureurs.stream().filter(c -> c.getDuration(checkPoint) != null)
				.sorted(Comparator.comparing(c -> c.getDuration(checkPoint)))
				.map(Coureur::clone)
				.collect(Collectors.toList());
	}

	@Override
	public String toString() {
		return "Marathon de " + this.nom + "(" + this.jour.format(DateTimeFormatter.ISO_LOCAL_DATE) + ")";
	}

	@Override
	public Iterator<Coureur> iterator() {
		TreeSet<Coureur> set = new TreeSet<>();
		this.coureurs.stream().forEach(x -> set.add(x.clone()));
		return set.iterator();
	}

}
