package marathon;

public interface MarathonFactory {
	
	Marathon getMarathon();
	
	Coureur getCoureur();

}
