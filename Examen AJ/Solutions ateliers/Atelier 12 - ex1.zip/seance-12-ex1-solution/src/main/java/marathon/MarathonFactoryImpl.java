package marathon;

public class MarathonFactoryImpl implements MarathonFactory {

	@Override
	public Marathon getMarathon() {
		return new MarathonImpl();
	}

	@Override
	public Coureur getCoureur() {
		return new CoureurImpl();
	}

}
