package marathon;

import java.time.Duration;

import marathon.Marathon.CheckPoint;

public interface Coureur extends Cloneable, Comparable<Coureur> {

	String getDossard();

	void setDossard(String dossard);

	String getNom();

	void setNom(String nom);

	String getPrenom();

	void setPrenom(String prenom);

	Duration getDuration(CheckPoint checkPoint);
	
	public Coureur clone();
	
	/*
	 * renvoie false si le checkpoint possède déjà un temps
	 */
	boolean ajouterCheck(CheckPoint checkPoint, Duration duration);

}