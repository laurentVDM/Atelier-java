package marathon;

import java.time.Duration;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import marathon.Marathon.CheckPoint;

class CoureurImpl implements Coureur {

	private String dossard;
	private String nom;
	private String prenom;
	private SortedMap<CheckPoint, Duration> mesChecksPoints = new TreeMap<CheckPoint, Duration>();

	public CoureurImpl() {
		
	}
	
	public CoureurImpl(String dossard, String nom, String prenom) {
		super();
		this.dossard = dossard;
		this.nom = nom;
		this.prenom = prenom;
	}

	@Override
	public String getDossard() {
		return dossard;
	}

	@Override
	public void setDossard(String dossard) {
		this.dossard = dossard;
	}

	@Override
	public String getNom() {
		return nom;
	}

	@Override
	public void setNom(String nom) {
		this.nom = nom;
	}

	@Override
	public String getPrenom() {
		return prenom;
	}

	@Override
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	@Override
	public Duration getDuration(CheckPoint checkPoint) {
		return mesChecksPoints.get(checkPoint);
	}

	/*
	 * renvoie false si le checkpoint possède déjà un temps
	 */
	@Override
	public boolean ajouterCheck(CheckPoint checkPoint, Duration duration) {
		if (this.mesChecksPoints.containsKey(checkPoint))
			return false;
		this.mesChecksPoints.put(checkPoint, duration);
		return true;
	}

	@SuppressWarnings("unchecked")
	@Override
	public CoureurImpl clone() {
		try {
			CoureurImpl clone = (CoureurImpl) super.clone();
			clone.mesChecksPoints = ((SortedMap<CheckPoint, Duration>) ((TreeMap<CheckPoint, Duration>) this.mesChecksPoints)
					.clone());
			return clone;
		} catch (CloneNotSupportedException e) {
			throw new InternalError();
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dossard == null) ? 0 : dossard.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CoureurImpl other = (CoureurImpl) obj;
		if (dossard == null) {
			if (other.dossard != null)
				return false;
		} else if (!dossard.equals(other.dossard))
			return false;
		return true;
	}

	@Override
	public String toString() {
		String ret = "";
		Set<CheckPoint> set = this.mesChecksPoints.keySet();
		
		for (CheckPoint iterable_element : set) {
			Duration duration = this.mesChecksPoints.get(iterable_element);
			String hms = String.format("%d:%02d:%02d", duration.toHours()%24, duration.toMinutes()%60,
					duration.getSeconds() % 60);
			ret += "\t "+iterable_element + " - " + hms+"\n";

			// Java 9String hms = String.format("%d:%02d:%02d",
			// duration.toHoursPart(), diff.toMinutesPart(),
			// diff.toSecondsPart());
		}
		return dossard + " : " + prenom + " " + nom + "\n" + ret;
	}

	@Override
	public int compareTo(Coureur arg0) {
		// TODO Auto-generated method stub
		return this.getDossard().compareTo(arg0.getDossard());
	}

}
