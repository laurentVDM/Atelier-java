package main;

import marathon.MarathonFactory;
import marathon.MarathonFactoryImpl;

public class Main {

	public static void main(String[] args) {
		MarathonFactory factory = new MarathonFactoryImpl();
		Client client = new Client();
		client.setMarathonFactory(factory);
		client.startMarathon();
	}

}
