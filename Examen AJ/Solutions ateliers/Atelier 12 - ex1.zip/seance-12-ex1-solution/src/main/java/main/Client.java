package main;

import java.time.Duration;
import java.time.LocalDate;

import marathon.Coureur;
import marathon.Marathon;
import marathon.MarathonFactory;
import marathon.Marathon.CheckPoint;

public class Client {
	
	private MarathonFactory factory;
	
	public void setMarathonFactory(MarathonFactory factory) {
		this.factory = factory;
	}
	
	public void startMarathon() {
		Marathon bxl = this.factory.getMarathon();
		bxl.setNom("Bruxelles");
		bxl.setJour(LocalDate.of(2022, 10, 7));
		
		Coureur coureur1 = this.factory.getCoureur();
		coureur1.setDossard("1");
		coureur1.setNom("Leleux");
		coureur1.setPrenom("Laurent");
		bxl.inscrire(coureur1);
		
		Coureur coureur2 = this.factory.getCoureur();
		coureur2.setDossard("2");
		coureur2.setNom("Baroni");
		coureur2.setPrenom("Raphaël");
		bxl.inscrire(coureur2);
		
		Coureur coureur3 = this.factory.getCoureur();
		coureur3.setDossard("3");
		coureur3.setNom("Ferneeuw");
		coureur3.setPrenom("Stéphanie");
		bxl.inscrire(coureur3);

		bxl.ajouterCheck("1", CheckPoint.CHECK0, Duration.ofSeconds(0));
		bxl.ajouterCheck("2", CheckPoint.CHECK0, Duration.ofSeconds(0));
		bxl.ajouterCheck("3", CheckPoint.CHECK0, Duration.ofSeconds(100));
		bxl.ajouterCheck("1", CheckPoint.CHECK1, Duration.ofSeconds(3200));
		bxl.ajouterCheck("2", CheckPoint.CHECK1, Duration.ofSeconds(2800));
		bxl.ajouterCheck("3", CheckPoint.CHECK1, Duration.ofSeconds(3000));
		bxl.ajouterCheck("1", CheckPoint.CHECK2, Duration.ofSeconds(6800));
		bxl.ajouterCheck("3", CheckPoint.CHECK3, Duration.ofSeconds(10000));

		System.out.println(bxl);
		bxl.forEach(System.out::println);
	}

}
