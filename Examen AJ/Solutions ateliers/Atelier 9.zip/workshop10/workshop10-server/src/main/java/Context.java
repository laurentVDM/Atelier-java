import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Context {
    private static Properties props = new Properties();

    public static void load(String filename) {
        try {
            System.out.println("file:"+Context.class.getClassLoader().getResource(filename).getFile());
            FileInputStream in = new FileInputStream(Context.class.getClassLoader().getResource(filename).getFile());
            props.load(in);
            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getProperty(String key) {
        return props.getProperty(key);
    }
}

/*
// This code would lead to the same result as here above !
// But instead of passing the filename, only the basename is required : e.g, client for the file client.properties
public class Context {
    private static ResourceBundle props;

    public static void load(String basename){
        props = ResourceBundle.getBundle(basename);
    }

    public static String getProperty(String key){
        return props.getString(key);
    }
}
*/

