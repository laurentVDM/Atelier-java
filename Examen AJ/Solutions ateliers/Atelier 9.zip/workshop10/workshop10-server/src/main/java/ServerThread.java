import java.io.*;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ServerThread extends Thread {
    private Socket socket = null;
    private static String END_MESSAGE = "/END";
    private ObjectOutputStream out;
    private ObjectInputStream in;

    public ServerThread(Socket socket) {
        this.socket = socket;

        try {
            this.out = new ObjectOutputStream(this.socket.getOutputStream());
            this.in = new ObjectInputStream(this.socket.getInputStream());
        } catch (IOException e) {
            System.out.println("Exception caught when trying to init communications");
            System.out.println(e.getMessage());
        }


    }

    @Override
    public void run() {
        try {
            Message message;
            while ((message = (Message) in.readObject()) != null) {
                System.out.println("Message from client : " + message);
                message.setTimeReceivedByServer(LocalDateTime.now());
                Server.broadcast(message);
                if (message.getContent().contains(END_MESSAGE))
                    break;
            }
            socket.close();
            System.out.println("A client has left the group!");

        } catch (IOException e) {
            System.out.println("Exception caught when trying to listen for a communication");
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void send(Message message) {
        try {
            out.writeObject(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
