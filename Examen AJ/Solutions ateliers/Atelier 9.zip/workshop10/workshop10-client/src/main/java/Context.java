import java.io.*;
import java.util.Properties;
import java.util.ResourceBundle;

public class Context {
    private static Properties props = new Properties();

    public static void load(String filename) {
        try (FileInputStream in = new FileInputStream(Context.class.getClassLoader().getResource(filename).getFile())) {
            props.load(in);
            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getProperty(String key) {
        return props.getProperty(key);
    }

    public static void setPropertyAndStore(String filename, String key, String value) {
        try {
            try (FileOutputStream out = new FileOutputStream(Context.class.getClassLoader().getResource(filename).getFile())) {
                props.setProperty(key, value);
                props.store(out, null);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

/*
// This code would lead to the same result as here above !
// But instead of passing the filename, only the basename is required : e.g, client for the file client.properties
public class Context {
    private static ResourceBundle props;

    public static void load(String basename){
        props = ResourceBundle.getBundle(basename);
    }

    public static String getProperty(String key){
        return props.getString(key);
    }
}
*/

