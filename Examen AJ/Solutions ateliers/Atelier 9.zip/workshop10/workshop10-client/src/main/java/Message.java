import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Message implements Serializable {
    private String author;
    private String content;
    private LocalDateTime timeReceivedByServer;

    public Message(String author, String content) {
        this.author = author;
        this.content = content;
    }

    public String getAuthor() {
        return author;
    }

    public String getContent() {
        return content;
    }

    public LocalDateTime getTimeReceivedByServer() {
        return timeReceivedByServer;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setTimeReceivedByServer(LocalDateTime timeReceivedByServer) {
        this.timeReceivedByServer = timeReceivedByServer;
    }


    @Override
    public String toString() {
        if (timeReceivedByServer != null)
            return "(" + timeReceivedByServer.format(DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm")) + ") " + author + " : " + content;
        return author + " : " + content;
    }
}
