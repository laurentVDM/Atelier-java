package commands;

import java.util.List;

import server.Command;

/**
 * Create a directory
 */
public class MKD implements Command {

	@Override
	public void execute(List<String> args) {
		// Do not implement !
		System.out.println("MKD command executed");
	}

}
