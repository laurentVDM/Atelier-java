package blacklist;

import domaine.Query;

public interface BlacklistService {
	
	public boolean check(Query query);

}
